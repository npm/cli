
#ifndef __taskmanager_marshal_MARSHAL_H__
#define __taskmanager_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* VOID:INT,INT (/home/exec/code/my/checkouts/awn/applets/taskmanager/taskmanager-marshal.list:1) */
extern void taskmanager_marshal_VOID__INT_INT (GClosure     *closure,
                                               GValue       *return_value,
                                               guint         n_param_values,
                                               const GValue *param_values,
                                               gpointer      invocation_hint,
                                               gpointer      marshal_data);

G_END_DECLS

#endif /* __taskmanager_marshal_MARSHAL_H__ */

